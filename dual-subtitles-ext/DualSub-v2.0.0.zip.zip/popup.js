document.addEventListener('DOMContentLoaded', () => {
  const sourceEl = document.getElementById("sourceLang");
  const targetEl = document.getElementById("targetLang");
  const applyBtn = document.getElementById("applyBtn");
  const swapBtn  = document.getElementById("swapBtn");

  // Load saved settings
  chrome.storage.sync.get({ sourceLang: "auto", targetLang: "en" }, (s) => {
    sourceEl.value = s.sourceLang;
    targetEl.value = s.targetLang;
  });

  // Swap source ↔ target (skip "auto" as target)
  swapBtn.addEventListener("click", () => {
    const srcVal = sourceEl.value;
    const tgtVal = targetEl.value;
    // Only swap if source is not "auto"
    if (srcVal !== "auto") {
      sourceEl.value = tgtVal;
      targetEl.value = srcVal;
    }
  });

  // Apply and broadcast to active tab
  applyBtn.addEventListener("click", () => {
    const sourceLang = sourceEl.value;
    const targetLang = targetEl.value;

    chrome.storage.sync.set({ sourceLang, targetLang }, () => {
      // Notify the active tab's content script immediately
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {
            type: "SETTINGS_UPDATED",
            sourceLang,
            targetLang,
          });
        }
      });

      // Visual confirmation
      applyBtn.textContent = "✓ Applied!";
      applyBtn.classList.add("saved");
      setTimeout(() => {
        applyBtn.textContent = "Apply Language Pair";
        applyBtn.classList.remove("saved");
      }, 2000);
    });
  });
});